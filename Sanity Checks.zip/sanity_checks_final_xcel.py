#import sanity_with_pass_fail
#import sanity_only_pass_fail_tag


import glob
import csv
import os
#from glob import glob
try:
    os.remove('sanity.csv')
except OSError:
    pass
with open('sanity.csv', 'a') as singleFile:
    code=open('sanity.csv',"w")
    code.write("Workflow_Name,Sanity Check, Pass/Fail, Comments \n")
    code.close()
    for csv in glob.glob('*.csv'):
        if csv == 'sanity.csv':
            pass
        else:
            for line in open(csv, 'r'):
                singleFile.write(line)

"""with open('output.txt','wb') as fout:
    wout = csv.writer(fout,delimiter=',') 
    interesting_files = glob.glob("*.csv") 
    for filename in interesting_files: 
        print ('Processing',filename) 
        # Open and process file
        h = True
        with open(filename,'rb') as fin:
            if h:
                h = False
            else:
                fin.next()#skip header
            for line in csv.reader(fin,delimiter=','):
                wout.writerow(line)"""






