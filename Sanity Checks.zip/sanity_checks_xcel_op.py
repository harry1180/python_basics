import os,glob,time
import re
from bs4 import BeautifulSoup
currentDirABSPath=os.path.split(os.path.abspath(__file__))[0]
startTime=time.time();
def extractQueries(sourceFolder="SourceXMLs",targetFolder="Sanity_checks_op",targetFileExt=".csv"):
    sourceFolderABSPath=os.path.join(currentDirABSPath,sourceFolder);
    targetFolderABSPath=os.path.join(currentDirABSPath);
    try:
        os.mkdir(targetFolderABSPath)
    except:
        pass
    stringtoGetXMLs=os.path.join(sourceFolder,"*.xml")
    filesList=glob.glob(stringtoGetXMLs);
    #print("ABS1",sourceFolderABSPath);
    #print("ABS2",targetFolderABSPath);
    
    for inputFile in filesList:
        print("------------------File Name------------------------")
        print("\n\nFilename:",os.path.split(inputFile)[1]);
        soup=BeautifulSoup(open(inputFile),"lxml")

        
        outputFile=inputFile.split(os.sep)[-1];
        #outputFile='harry.csv'
        outputFilePath=os.path.join(outputFile[:-4])+targetFileExt;
        #outputFilePath='larry.csv'
        #targetFolder

        code=open(outputFilePath,"w")
        #point1
        
        workflow_name = soup.find_all("workflow")
        for each in workflow_name:
            if each['name'].startswith('wf_'):
                code.write(each['name']+",Standard workflow naming convention starts with \'wf_\'")
                code.write(",PASS,"+each['name'])
                code.write('\n')
                
                
                
            else:
                
                code.write("FAIL")
                
        
        def work_flow_check():
            for each in workflow_name:
                if each['name'].startswith('wf_'):
                    code.write(each['name'])
        def work_flow_check_N_W():
                for each in workflow_name:
                    if each['name'].startswith('wf_N') or each['name'].startswith('wf_W') or each['name'].startswith('wf_WK') or each['name'].startswith('wf_WI') or each['name'].startswith('wf_MT'):
                        code.write(each['name'])
        def workflow_check_FF_X_ST():
            for each in workflow_name:
                if each['name'].startswith('wf_FF') or each['name'].startswith('wf_P')or each['name'].startswith('wf_ST'):
                    code.write(each['name'])
        def work_flow_check_x_ff():
            for each in workflow_name:
                if each['name'].startswith('wf_FF') or each['name'].startswith('wf_P'):
                    code.write(each['name'])
                else:
                    code.write(each['name'])
        def collectstats(cs):
            cs=0
            for each in base_view_check_ps:
                for j in list1:
                    if j == each['value']:
                        cs+=1
                        print (cs,'this is cs')
                return cs
        sql_query_revert = soup.find_all("attribute")
        for each in sql_query_revert:
            if each['name']=='Sql Query':
                work_flow_check()
                code.write(",sql query at mapping and session level are different")
                code.write(",FAIL")
                code.write('\n')
                
            else:
                work_flow_check()
                code.write(",Source qualifier query at mapping and session level are same")
                code.write(",PASS")
                code.write('\n')
                
                break
        delimiter_check = soup.find_all("flatfile")
        for each in delimiter_check:
            work_flow_check()
            code.write(",Flat File Delimiter given is:,NA,")
            print(each['delimiters'].encode('latin-1'))
            code.write(each['delimiters']+" :Please verify value")
            code.write('\n')
            break
        task_type = soup.find_all("taskinstance", attrs = {"tasktype":"Session"})
        for each in task_type:
            if each['taskname'].startswith('s_m_'):
                work_flow_check()
                code.write(",Standard session naming convention should start with 's_m_' \t ,")
                code.write("PASS,"+each['taskname'])
                code.write('\n')
            else:
                work_flow_check()
                code.write(",Standard session naming convention should start with 's_m_' \t ,")
                code.write("FAIL")
                code.write('\n')
            #if each["TASKNAME"]= point2
        task_type = soup.find_all("taskinstance", attrs = {"tasktype":"Session"})
        for each in task_type:
            if each["fail_parent_if_instance_fails"]!= 'YES':
                work_flow_check()
                code.write(",Fail_parent_if_instance_fails should be yes,")
                code.write("FAIL")
                code.write('\n')
            else:
                work_flow_check()
                code.write(",Fail_parent_if_instance_fails should be yes,")
                code.write("PASS")
                code.write('\n')
        task_type = soup.find_all("taskinstance", attrs = {"tasktype":"Session"})
        for each in task_type:
            if each["fail_parent_if_instance_did_not_run"]!='YES':
                work_flow_check()
                code.write(",FAIL_PARENT_IF_INSTANCE_DID_NOT_RUN should be yes,")
                code.write("FAIL")
                code.write('\n')
            else:
                work_flow_check()
                code.write(",FAIL_PARENT_IF_INSTANCE_DID_NOT_RUN should be yes,")
                code.write("PASS")
                code.write('\n')
        for each in task_type:
            if each["reusable"]!='NO':
                work_flow_check()
                code.write(",Session Reusable option should be checked,")
                code.write('\n')
            else:
                work_flow_check()
                code.write(",Session Reusable option should be checked,")
                code.write("PASS")
                code.write('\n')
        for each in task_type:
            if each["treat_inputlink_as_and"]!="YES":
                work_flow_check()
                code.write(",Treat_inputlink_as_and option should be checked,")
                code.write("FAIL")
                code.write('\n')
            else:
                work_flow_check()
                code.write(",Treat_inputlink_as_and option should be checked,")
                code.write("PASS")
                code.write('\n')
        configContents=soup.find_all("config",attrs={"name":["default_session_config"]})
        cList=[]
        configDict={}
        #point5 covered
        for instance in configContents:
            tempSrcName=instance['name']
            cList.append(tempSrcName)
            configDict[tempSrcName]={}.fromkeys(["Stop on errors","Save session log for these runs","Pre 85 Timestamp Compatibility","Override tracing"],"")
            instanceContents=instance.find_all("attribute",attrs={"name" : ["Stop on errors"]})
            for eachTag in instanceContents:
                if (eachTag['name']== "Stop on errors" and eachTag['value']!="1"):
                    work_flow_check()
                    code.write(",Stop on errors should be 1,")
                    code.write("FAIL")
                    code.write('\n')
                else:
                    work_flow_check()
                    code.write(",Stop on errors should be 1,")
                    code.write("PASS,given value is :"+eachTag['value'])
                    code.write('\n')
            for eachTag in instanceContents:
                if (eachTag['name']== "Save session log for these runs" and eachTag['value']!="5"):
                    work_flow_check()
                    code.write(",Save session log for these runs should be 5,")
                    code.write("FAIL,given value is :"+eachTag['value'])
                    code.write('\n')
                else:
                    work_flow_check()
                    code.write(",Save session log for these runs should be 5,")
                    code.write("PASS")
                    code.write('\n')
            for eachTag in instanceContents:
                if (eachTag['name']== "Pre 85 Timestamp Compatibility" and eachTag['value']!="YES"):
                    work_flow_check()
                    code.write(",Pre 85 Timestamp Compatibility should be yes,")
                    code.write("FAIL")
                    code.write('\n')
                else:
                    work_flow_check()
                    code.write(",Pre 85 Timestamp Compatibility should be yes,")
                    code.write("PASS")
                    code.write('\n')
            for eachTag in instanceContents:
                if (eachTag['name']== "Override tracing" and eachTag['value']!="Normal"):
                    work_flow_check()
                    code.write(",Override tracing should be given as Normal,")
                    code.write("FAIL,Please Validate")
                    code.write('\n')
                else:
                    work_flow_check()
                    code.write(",Override tracing should be given as NORMAL,")
                    code.write("PASS,")
                    code.write('\n')
        sourceContents1=soup.find_all("transformation",attrs={"type":["Source Qualifier"]})
        sList1=[]
        sourcesDict1={}
        for instance in sourceContents1:
            tempSrcName=instance['name']
            sList1.append(tempSrcName)
            sourcesDict1[tempSrcName]={}.fromkeys(["Tracing Level"],"")
            instanceContents1=instance.find_all("tableattribute",attrs={"name" : ["Tracing Level"]})
            for eachTag in instanceContents1:
                if (eachTag['name']=="Tracing Level" and eachTag['value']!="Normal" ):
                    code.write("Tracing Level should be normal :"+instance['name'])
        sessionwContents=soup.find_all("sessionextension")
        sList=[]
        sessionDict={}
        for instance in sessionwContents:
            tempSrcName=instance['name']
            sList.append(tempSrcName)
            instanceContents=instance.find_all("attribute",attrs={"name":["Target load type","Reject file directory" ,"Reject filename","Output filename","Output file directory","Merge File Directory","Merge File Name" ]})
            #code.write("instance name:"+instance['sinstancename'])
            for eachTag in instanceContents:
                if (eachTag['name']== "Target load type"):
                    work_flow_check()
                    code.write(",Target load Type  :,NA,Please Validate :   "+eachTag['value'])
                    code.write('\n')
            for eachTag in instanceContents:
                if (eachTag['name']== "Reject file directory" ):
                    work_flow_check()
                    code.write(",Reject file directory: ,NA,Please Validate : "+eachTag['value'])
                    code.write('\n')
            for eachTag in instanceContents:
                if (eachTag['name']== "Reject filename" ):
                    work_flow_check()
                    code.write(",Reject Filename is ,NA,Please Validate : "+eachTag['value'])
                    #code.write(",Please Validate")
                    code.write('\n')
            for eachTag in instanceContents:
                if (eachTag['name']=="Output filename"):
                    work_flow_check()
                    code.write(",Output filename is ,NA,Please Validate : "+eachTag['value'])
                    code.write('\n')
                    #code.write("\n\n here i am ")
            for eachTag in instanceContents:
                if (eachTag['name']=="Output file directory"):
                    workflow_check_FF_X_ST()
                    code.write(",Output file directory is ,NA,Please Validate : " +eachTag['value'])
                    code.write("\n ")
            for eachTag in instanceContents:
                if (eachTag['name']=="Merge File Directory"):
                    work_flow_check()
                    code.write(",Merge File Directory given is ,NA,Please Validate : " +eachTag['value'])
                    code.write('\n')
            
            for eachTag in instanceContents:
                if (eachTag['name']=="Merge File Name"):
                    work_flow_check()
                    code.write(",Merge File Name given is,NA,Please Validate " +eachTag['value']+",")
                    code.write('\n')
        sessionContents=soup.find_all("sessionextension")#,attrs={"name":["Relational Writer"]})
        sList=[]
        sessionDict={}
        for instance in sessionContents:     
            tempSrcName=instance['name']
            sList.append(tempSrcName)
            instanceContents=instance.find_all("attribute",attrs={"name":["Target load type"]})
            
            
            for eachTag in instanceContents:
                if (eachTag['name']== "Insert" and "YES" not in eachTag[value]):
                    work_flow_check()
                    code.write(instance['sinstancename'])
                    code.write(",Insert should be yes,")
                    code.write("FAIL")
                    code.write('\n')
                else:
                    work_flow_check()
                    code.write(", Insert is ticked,")
                    code.write("PASS")
                    code.write('\n')
                    break
                
                if (eachTag['name']== "Update as Update" and eachTag[value]!="NO"):
                                           work_flow_check()
                                           code.write(instance['sinstancename'])
                                           code.write(",   :Update as Update should be no for,")
                                           code.write(instance['sinstancename'])
                                           code.write("FAIL")
                                           code.write('\n')
                
                else:
                    work_flow_check_N_W()
                    code.write("PASS")
                    code.write('\n')
                if (eachTag['name']== "Update as Insert" and eachTag[value]!="NO"):
                    #code.write(instance['sinstancename'])
                    work_flow_check_N_W()
                    code.write(",   Update as Insert should be no,")
                    code.write("FAIL")
                    code.write('\n')
                else:
                    work_flow_check_N_W()
                    code.write(",   Update as Insert is  not ticked")
                    code.write("PASS")
                    code.write('\n')
                if (eachTag['name']== "Update else Insert" and eachTag[value]!="NO"):
                     #code.write(instance['sinstancename'])
                    work_flow_check_N_W()
                    code.write(",Update as Insert should be no,")
                    code.write("FAIL")
                    code.write('\n')
                else:
                    work_flow_check_N_W()
                    code.write(",Update as Insert is  not ticked,")
                    code.write("PASS")
                    code.write('\n')
        sessionProps = soup.find_all("sesstransformationinst",attrs={"transformationtype":["Target Definition"]})
        dict_props = {}.fromkeys(["Table Name Prefix"],"")
        for eachTag in sessionProps:
            each = eachTag.find_all("attribute", attrs = {"name":["Table Name Prefix"]})
            for i in each:
                dict_props[i["name"]] = i["value"]
                code.write(" ")
                work_flow_check_x_ff()
                code.write("  ,Table Prefix name:  ,NA,Please Validate : "+dict_props[i["name"]])
                code.write('\n')
        session_Config = soup.find_all("attribute", attrs = {"name":["Pushdown Optimization","Session Log File Name","Session Log File directory","Parameter Filename","Allow Temporary View for Pushdown"]})
        for each in session_Config:
            if (each['name'] == "DTM buffer size"):
                work_flow_check()
                code.write(",DTM buffer size :,"+each['value'])
                code.write(",Please Validate")
                code.write('\n')
            if  (each['name'] == "DTM buffer size"):
                work_flow_check()
                code.write(",DTM buffer size:,   "+each['value'])
                code.write(",Please Validate")
                code.write('\n')
            if (each['name'] == "Pushdown Optimization"):
                work_flow_check()
                code.write(",Pushdown Optimization ,NA,Please Validate : "+each['value'])
                code.write('\n')
            if (each['name'] == "Session Log File Name"):
                work_flow_check()
                code.write(",Session Log File Name,NA,Please Validate :  "+each['value'])
                code.write('\n')
            if (each['name'] == "Session Log File directory"):
                work_flow_check()
                code.write(",Session Log File directory,NA,Please Validate : "+each['value'])
                code.write('\n')
            if (each['name'] == "Parameter Filename" and each['value']!= ""):
                work_flow_check()
                code.write(",Parameter File Name,NA,Please Validate : "+each['value'])
                code.write('\n')
            if (each['name']== "Allow Temporary View for Pushdown" and each['value']!="NO"):
                work_flow_check()
                code.write(",Allow Temporary View for Pushdown,NA,"+each['value'])
                code.write('\n')
                    
            #if (each['name']=="$$LastExtractDate") :
                #code.write("lastextractdate found: "+each['name'])
                
            #elif count>=1:
             #   code.write("last extract date found \n"+each['name'])
              #  print (count);
               # #break
            #elif ((each['name']!="$$LastExtractDate") and count==0):
             #   code.write("last extract date not found\n")
              #  print (count)
               # continue
        base_view_check= soup.find_all("attribute", attrs={"name":["Sql Query","Pre SQL","Post SQL"]})
        base_view_check_ps= soup.find_all("attribute", attrs={"name":["Post SQL"]})
        #pattern = re.compile("^\$\$")
        list=['$$CLICKSDB','$$COMREFDB','$$CTLDB','$$ETLONLYDB','$$FINLGLDB','$$GALAXYDB','$$HREDUDB','$$IBDB','$$INVFLMTDB','$$MGRE3NFDB','$$NOSTGDATADB','$$RODATADB','$$SANDBOXDB','$$SECURITYDB','$$SERVICEDB','$$SLSMKTDB','$$SLSORDDB','$$TRANSLATIONDB','$$JIDB','$$SUPPORTDB','$$HRDB','$$W_SLS_MBR_OBI_L','$$APPUSGDB','$$EDWPROD','$$PUBLISHLOGDB','$$LZCTLDB','$$LZDB','$$LZETLONLYDB','$$LZTRANSLATIONDB','$$LZWORKDB','$$AUDITDB','$$TOOLSCTLDB','$$BICAFEDATADB','$$ASBIDB','$$BIDSMETRICSDB','$$CCERTEMPDB','$$OTSSTGDB','$$OTSDB','$$LZ_BASEVIEWS','$$TEMPBEHDB','$$BEHTEMPDB','$$NRTSTGDB','$$NRTACCUMDB','$$NRTARCHIVEDB','$$NRTNCRDB','$$SWEEPSDATADB','$$PMMDATADB','$$GRMTDATADB','$$GRMTBVDB','$$SOPDATADB','$$MBRDATADB','$$MBRBVDB','$$GRAYMKTDB','$$MARKETINGDATADB','$$GGSRCDB','$$CVBKGSDATADB','$$ENGGDB','$$ONEVIEWDATADB','$$REPLICDB','$$SCSUBVDB','$$EXAASDB','$$ETLOFFLOADDB','$$PHVBVDB','$$CTLIPTDB','$$APJPDATADB','$$APJPDATASVDB'    
       , '$$CLICKSDB_DV','$$COMREFDB_DV','$$CTLDB_DV','$$ETLONLYDB_DV','$$FINLGLDB_DV','$$GALAXYDB_DV','$$HREDUDB_DV','$$IBDB_DV','$$INVFLMTDB_DV','$$MGRE3NFDB_DV','$$NOSTGDATADB_DV','$$RODATADB_DV','$$SANDB_DVOXDB_DV','$$SECURITYDB_DV','$$SERVICEDB_DV','$$SLSMKTDB_DV','$$SLSORDDB_DV','$$TRANSLATIONDB_DV','$$JIDB_DV','$$SUPPORTDB_DV','$$HRDB_DV','$$W_SLS_MBR_OBI_L','$$APPUSGDB_DV','$$EDWPROD','$$PUBLISHLOGDB_DV','$$LZCTLDB_DV','$$LZDB_DV','$$LZETLONLYDB_DV','$$LZTRANSLATIONDB_DV','$$LZWORKDB_DV','$$AUDITDB_DV','$$TOOLSCTLDB_DV','$$BICAFEDATADB_DV','$$ASBIDB_DV','$$BIDSMETRICSDB_DV','$$CCERTEMPDB_DV','$$OTSSTGDB_DV','$$OTSDB_DV','$$LZ_BASEVIEWS','$$TEMPBEHDB_DV','$$BEHTEMPDB_DV','$$NRTSTGDB_DV','$$NRTACCUMDB_DV','$$NRTARCHIVEDB_DV','$$NRTNCRDB_DV','$$SWEEPSDATADB_DV','$$PMMDATADB_DV','$$GRMTDATADB_DV','$$GRMTBVDB_DV','$$SOPDATADB_DV','$$MBRDATADB_DV','$$MBRBVDB_DV','$$GRAYMKTDB_DV','$$MARKETINGDATADB_DV','$$GGSRCDB_DV','$$CVBKGSDATADB_DV','$$ENGGDB_DV','$$ONEVIEWDATADB_DV','$$REPLICDB_DV','$$SCSUBVDB_DV','$$EXAASDB_DV','$$ETLOFFLOADDB_DV','$$PHVBVDB_DV','$$CTLIPTDB_DV','$$APJPDATADB_DV','$$APJPDATASVDB_DV'
            
        ,'$$CLICKSDB_TS','$$COMREFDB_TS','$$CTLDB_TS','$$ETLONLYDB_TS','$$FINLGLDB_TS','$$GALAXYDB_TS','$$HREDUDB_TS','$$IBDB_TS','$$INVFLMTDB_TS','$$MGRE3NFDB_TS','$$NOSTGDATADB_TS','$$RODATADB_TS','$$SANDB_TSOXDB_TS','$$SECURITYDB_TS','$$SERVICEDB_TS','$$SLSMKTDB_TS','$$SLSORDDB_TS','$$TRANSLATIONDB_TS','$$JIDB_TS','$$SUPPORTDB_TS','$$HRDB_TS','$$W_SLS_MBR_OBI_L','$$APPUSGDB_TS','$$EDWPROD','$$PUBLISHLOGDB_TS','$$LZCTLDB_TS','$$LZDB_TS','$$LZETLONLYDB_TS','$$LZTRANSLATIONDB_TS','$$LZWORKDB_TS','$$AUDITDB_TS','$$TOOLSCTLDB_TS','$$BICAFEDATADB_TS','$$ASBIDB_TS','$$BIDSMETRICSDB_TS','$$CCERTEMPDB_TS','$$OTSSTGDB_TS','$$OTSDB_TS','$$LZ_BASEVIEWS','$$TEMPBEHDB_TS','$$BEHTEMPDB_TS','$$NRTSTGDB_TS','$$NRTACCUMDB_TS','$$NRTARCHIVEDB_TS','$$NRTNCRDB_TS','$$SWEEPSDATADB_TS','$$PMMDATADB_TS','$$GRMTDATADB_TS','$$GRMTBVDB_TS','$$SOPDATADB_TS','$$MBRDATADB_TS','$$MBRBVDB_TS','$$GRAYMKTDB_TS','$$MARKETINGDATADB_TS','$$GGSRCDB_TS','$$CVBKGSDATADB_TS','$$ENGGDB_TS','$$ONEVIEWDATADB_TS','$$REPLICDB_TS','$$SCSUBVDB_TS','$$EXAASDB_TS','$$ETLOFFLOADDB_TS','$$PHVBVDB_TS','$$CTLIPTDB_TS','$$APJPDATADB_TS','$$APJPDATASVDB_TS'

        ,'CLICKSDB','COMREFDB','CTLDB','ETLONLYDB','FINLGLDB','GALAXYDB','HREDUDB','IBDB','INVFLMTDB','MGRE3NFDB','NOSTGDATADB','RODATADB','SANDBOXDB','SECURITYDB','SERVICEDB','SLSMKTDB','SLSORDDB','TRANSLATIONDB','JIDB','SUPPORTDB','HRDB','W_SLS_MBR_OBI_L','APPUSGDB','EDWPROD','PUBLISHLOGDB','LZCTLDB','LZDB','LZETLONLYDB','LZTRANSLATIONDB','LZWORKDB','AUDITDB','TOOLSCTLDB','BICAFEDATADB','ASBIDB','BIDSMETRICSDB','CCERTEMPDB','OTSSTGDB','OTSDB','LZ_BASEVIEWS','TEMPBEHDB','BEHTEMPDB','NRTSTGDB','NRTACCUMDB','NRTARCHIVEDB','NRTNCRDB','SWEEPSDATADB','PMMDATADB','GRMTDATADB','GRMTBVDB','SOPDATADB','MBRDATADB','MBRBVDB','GRAYMKTDB','MARKETINGDATADB','GGSRCDB','CVBKGSDATADB','ENGGDB','ONEVIEWDATADB','REPLICDB','SCSUBVDB','EXAASDB','ETLOFFLOADDB','PHVBVDB','CTLIPTDB','APJPDATADB','APJPDATASVDB'

        ,'CLICKSDB_DV','COMREFDB_DV','CTLDB_DV','ETLONLYDB_DV','FINLGLDB_DV','GALAXYDB_DV','HREDUDB_DV','IBDB_DV','INVFLMTDB_DV','MGRE3NFDB_DV','NOSTGDATADB_DV','RODATADB_DV','SANDB_DVOXDB_DV','SECURITYDB_DV','SERVICEDB_DV','SLSMKTDB_DV','SLSORDDB_DV','TRANSLATIONDB_DV','WORKDB_DV','JIDB_DV','SUPPORTDB_DV','HRDB_DV','W_SLS_MBR_OBI_L','APPUSGDB_DV','EDWPROD','PUBLISHLOGDB_DV','LZCTLDB_DV','LZDB_DV','LZETLONLYDB_DV','LZTRANSLATIONDB_DV','LZWORKDB_DV','AUDITDB_DV','TOOLSCTLDB_DV','BICAFEDATADB_DV','ASBIDB_DV','BIDSMETRICSDB_DV','CCERTEMPDB_DV','OTSSTGDB_DV','OTSDB_DV','LZ_BASEVIEWS','TEMPBEHDB_DV','BEHTEMPDB_DV','NRTSTGDB_DV','NRTACCUMDB_DV','NRTARCHIVEDB_DV','NRTNCRDB_DV','SWEEPSDATADB_DV','PMMDATADB_DV','GRMTDATADB_DV','GRMTBVDB_DV','SOPDATADB_DV','MBRDATADB_DV','MBRBVDB_DV','GRAYMKTDB_DV','MARKETINGDATADB_DV','GGSRCDB_DV','CVBKGSDATADB_DV','ENGGDB_DV','ONEVIEWDATADB_DV','REPLICDB_DV','SCSUBVDB_DV','EXAASDB_DV','ETLOFFLOADDB_DV','PHVBVDB_DV','CTLIPTDB_DV','APJPDATADB_DV','APJPDATASVDB_DV'

        ,'CLICKSDB_TS','COMREFDB_TS','CTLDB_TS','ETLONLYDB_TS','FINLGLDB_TS','GALAXYDB_TS','HREDUDB_TS','IBDB_TS','INVFLMTDB_TS','MGRE3NFDB_TS','NOSTGDATADB_TS','RODATADB_TS','SANDB_TSOXDB_TS','SECURITYDB_TS','SERVICEDB_TS','SLSMKTDB_TS','SLSORDDB_TS','TRANSLATIONDB_TS','WORKDB_TS','JIDB_TS','SUPPORTDB_TS','HRDB_TS','W_SLS_MBR_OBI_L','APPUSGDB_TS','EDWPROD','PUBLISHLOGDB_TS','LZCTLDB_TS','LZDB_TS','LZETLONLYDB_TS','LZTRANSLATIONDB_TS','LZWORKDB_TS','AUDITDB_TS','TOOLSCTLDB_TS','BICAFEDATADB_TS','ASBIDB_TS','BIDSMETRICSDB_TS','CCERTEMPDB_TS','OTSSTGDB_TS','OTSDB_TS','LZ_BASEVIEWS','TEMPBEHDB_TS','BEHTEMPDB_TS','NRTSTGDB_TS','NRTACCUMDB_TS','NRTARCHIVEDB_TS','NRTNCRDB_TS','SWEEPSDATADB_TS','PMMDATADB_TS','GRMTDATADB_TS','GRMTBVDB_TS','SOPDATADB_TS','MBRDATADB_TS','MBRBVDB_TS','GRAYMKTDB_TS','MARKETINGDATADB_TS','GGSRCDB_TS','CVBKGSDATADB_TS','ENGGDB_TS','ONEVIEWDATADB_TS','REPLICDB_TS','SCSUBVDB_TS','EXAASDB_TS','ETLOFFLOADDB_TS','PHVBVDB_TS','CTLIPTDB_TS','APJPDATADB_TS','APJPDATASVDB_TS'

        ,'$$BASEVWDB_DV','$$CLICKSVWDB_DV','$$COMREFVWDB_DV','$$ETLVWDB_DV','$$FINGLVWDB_DV','$$FINLGLVWDB_DV','$$GALAXYVWDB_DV','$$HREDUVWDB_DV','$$IBVWDB_DV','$$INVFLMTVWDB_DV','$$SANDB_DVOXVWDB_DV','$$SECURITYVWDB_DV','$$SERVICEVWDB_DV','$$SLSMKTVWDB_DV','$$SLSORDVWDB_DV','$$HRVWDB_DV','$$IAMPVWDB_DV','$$ODMPVWDB_DV','$$EPSPVWDB_DV','$$PREPVWDB_DV','$$WWBPVWDB_DV','$$LZETLVWDB_DV','$$LZVWDB_DV','$$FETCHPVWDB_DV','$$QDIPVWDB_DV','$$S2RPVWDB_DV','$$MRMPVWDB_DV','$$DPADHOCPVWDB_DV','$$FINREVPVWDB_DV','$$CAPITALPVWDB_DV','$$FINCONFPVWDB_DV','$$FINEXTPVWDB_DV','$$ITEMHUBPVWDB_DV','$$EBIPVWDB_DV','$$BICAFEDATAVWDB_DV','$$LCMTPVWDB_DV','$$ASBIVWDB_DV','$$DISEPVWDB_DV','$$NGCCRMPVWDB_DV','$$CCERTEMPVWDB_DV','$$MFGSOPPVWDB_DV','$$OTSVWDB_DV','$$TEMPBEHVWDB_DV','$$BEHTEMPVWDB_DV','$$BIDSMETRICSVWDB_DV','$$NRTNCRVWDB_DV','$$NRTACCUMVWDB_DV','$$SWEEPSVWDB_DV','$$PMMDATAVWDB_DV','$$GRMTDATAVWDB_DV','$$SOPDATAVWDB_DV','$$MBRDATAVWDB_DV','$$GRAYMKTVWDB_DV','$$GGSRCVWDB_DV','$$MARKETINGDATAVWDB_DV','$$CVBKGSDATAVWDB_DV','$$ENGGVWDB_DV','$$REPLICVWDB_DV','$$EXAASVWDB_DV','$$REPLICVWDB_DV','$$CISCOREADYPVWDB_DV','$$CG1PVVWDB_DV','$$ENGGPVWDB_DV','$$PMCPVWDB_DV','$$HANAPVWDB_DV','$$TVBIPVWDB_DV','$$MBPVWDB_DV','$$ATHENAPVWDB_DV','$$CSIPPVWDB_DV','$$PPMPVWDB_DV','$$DFIPVWDB_DV','$$QDIPRODCOSTPVWDB_DV','$$GRAYMKTPVWDB_DV','$$TRANSACCPVWDB_DV','$$CVCMETPVWDB_DV','$$DSDPVWDB_DV','$$ESCPVWDB_DV','$$SAVMPVWDB_DV','$$OPPVWDB_DV','$$SCFINCOSTPVWDB_DV','$$APJPDATAVWDB_DV',

        '$$BASEVWDB_TS','$$CLICKSVWDB_TS','$$COMREFVWDB_TS','$$ETLVWDB_TS','$$FINGLVWDB_TS','$$FINLGLVWDB_TS','$$GALAXYVWDB_TS','$$HREDUVWDB_TS','$$IBVWDB_TS','$$INVFLMTVWDB_TS','$$SANDB_TSOXVWDB_TS','$$SECURITYVWDB_TS','$$SERVICEVWDB_TS','$$SLSMKTVWDB_TS','$$SLSORDVWDB_TS','$$HRVWDB_TS','$$IAMPVWDB_TS','$$ODMPVWDB_TS','$$EPSPVWDB_TS','$$PREPVWDB_TS','$$WWBPVWDB_TS','$$LZETLVWDB_TS','$$LZVWDB_TS','$$FETCHPVWDB_TS','$$QDIPVWDB_TS','$$S2RPVWDB_TS','$$MRMPVWDB_TS','$$DPADHOCPVWDB_TS','$$FINREVPVWDB_TS','$$CAPITALPVWDB_TS','$$FINCONFPVWDB_TS','$$FINEXTPVWDB_TS','$$ITEMHUBPVWDB_TS','$$EBIPVWDB_TS','$$BICAFEDATAVWDB_TS','$$LCMTPVWDB_TS','$$ASBIVWDB_TS','$$DISEPVWDB_TS','$$NGCCRMPVWDB_TS','$$CCERTEMPVWDB_TS','$$MFGSOPPVWDB_TS','$$OTSVWDB_TS','$$TEMPBEHVWDB_TS','$$BEHTEMPVWDB_TS','$$BIDSMETRICSVWDB_TS','$$NRTNCRVWDB_TS','$$NRTACCUMVWDB_TS','$$SWEEPSVWDB_TS','$$PMMDATAVWDB_TS','$$GRMTDATAVWDB_TS','$$SOPDATAVWDB_TS','$$MBRDATAVWDB_TS','$$GRAYMKTVWDB_TS','$$GGSRCVWDB_TS','$$MARKETINGDATAVWDB_TS','$$CVBKGSDATAVWDB_TS','$$ENGGVWDB_TS','$$REPLICVWDB_TS','$$EXAASVWDB_TS','$$REPLICVWDB_TS','$$CISCOREADYPVWDB_TS','$$CG1PVVWDB_TS','$$ENGGPVWDB_TS','$$PMCPVWDB_TS','$$HANAPVWDB_TS','$$TVBIPVWDB_TS','$$MBPVWDB_TS','$$ATHENAPVWDB_TS','$$CSIPPVWDB_TS','$$PPMPVWDB_TS','$$DFIPVWDB_TS','$$QDIPRODCOSTPVWDB_TS','$$GRAYMKTPVWDB_TS','$$TRANSACCPVWDB_TS','$$CVCMETPVWDB_TS','$$DSDPVWDB_TS','$$ESCPVWDB_TS','$$SAVMPVWDB_TS','$$OPPVWDB_TS','$$SCFINCOSTPVWDB_TS','$$APJPDATAVWDB_TS',

        'BASEVWDB_DV','CLICKSVWDB_DV','COMREFVWDB_DV','ETLVWDB_DV','FINGLVWDB_DV','FINLGLVWDB_DV','GALAXYVWDB_DV','HREDUVWDB_DV','IBVWDB_DV','INVFLMTVWDB_DV','SANDB_DVOXVWDB_DV','SECURITYVWDB_DV','SERVICEVWDB_DV','SLSMKTVWDB_DV','SLSORDVWDB_DV','HRVWDB_DV','IAMPVWDB_DV','ODMPVWDB_DV','EPSPVWDB_DV','PREPVWDB_DV','WWBPVWDB_DV','LZETLVWDB_DV','LZVWDB_DV','FETCHPVWDB_DV','QDIPVWDB_DV','S2RPVWDB_DV','MRMPVWDB_DV','DPADHOCPVWDB_DV','FINREVPVWDB_DV','CAPITALPVWDB_DV','FINCONFPVWDB_DV','FINEXTPVWDB_DV','ITEMHUBPVWDB_DV','EBIPVWDB_DV','BICAFEDATAVWDB_DV','LCMTPVWDB_DV','ASBIVWDB_DV','DISEPVWDB_DV','NGCCRMPVWDB_DV','CCERTEMPVWDB_DV','MFGSOPPVWDB_DV','OTSVWDB_DV','TEMPBEHVWDB_DV','BEHTEMPVWDB_DV','BIDSMETRICSVWDB_DV','NRTNCRVWDB_DV','NRTACCUMVWDB_DV','SWEEPSVWDB_DV','PMMDATAVWDB_DV','GRMTDATAVWDB_DV','SOPDATAVWDB_DV','MBRDATAVWDB_DV','GRAYMKTVWDB_DV','GGSRCVWDB_DV','MARKETINGDATAVWDB_DV','CVBKGSDATAVWDB_DV','ENGGVWDB_DV','REPLICVWDB_DV','EXAASVWDB_DV','REPLICVWDB_DV','CISCOREADYPVWDB_DV','CG1PVVWDB_DV','ENGGPVWDB_DV','PMCPVWDB_DV','HANAPVWDB_DV','TVBIPVWDB_DV','MBPVWDB_DV','ATHENAPVWDB_DV','CSIPPVWDB_DV','PPMPVWDB_DV','DFIPVWDB_DV','QDIPRODCOSTPVWDB_DV','GRAYMKTPVWDB_DV','TRANSACCPVWDB_DV','CVCMETPVWDB_DV','DSDPVWDB_DV','ESCPVWDB_DV','SAVMPVWDB_DV','OPPVWDB_DV','SCFINCOSTPVWDB_DV','APJPDATAVWDB_DV',
            ]
        list1=['COLLECT_STATS_WRAP','COLLECT']
        list_collect=['COLLECT']
        list_wrap=['COLLECT_STATS_WRAP']
        count=0
        c=0
        cs=0
        k=re.compile(r'(\$\$.*DB\..*.*$)')
        for each in base_view_check:
            for i in list:
                collectstats(cs)
                if i in each['value']:
                    print (i)
                    work_flow_check()
                    count=count+1
                    print(',invalid parameterisation, but collect stats is present ',count)
                    code.write(',Invalid parameterisation,FAIL,')
                    code.write( 'found the presence of :'+i)
                    code.write(":Please Validate\n")
                #if i not in each['value'] :
                    #work_flow_check()
                    #print(',Valid parameterisation, ',count)
                    #code.write(',Parameterisation looks okay,PASS,\n')
                    #break
        for each in base_view_check:
            for i in list_collect:
                if 'COLLECT' in each['value']:
                    work_flow_check()
                    print('Collect stats should be applied with Wrapper,FAIL')
                    code.write(',Collect stats should be applied with Wrapper,FAIL, \n')
                    break
                    

        """for each in base_view_check:
            print (count,'i m count')
            for i in list1:
                if i in each['value']:
                    c=c+1
                    
                    collectstats(cs)
                    print('this is c', c)
                    if c!=0 and count!=0:
                        #work_flow_check()
                        print('invalids',i)
                        code.write(',Invalid parameterisation in Post Sql but collect stats is also found,FAIL,')
                        code.write('found the presence of :'+i+str(c)+'times')
                        code.write(":Please Validate\n")
                    elif c==0 and count!=0:
                        work_flow_check()
                        print('base table reference')
                        code.write(',Base table reference is found'+c+'times and collect stats is found'+cs+'times in post sql,PASS,Please Validate,\n')
                    elif c==0 and count==0:
                        work_flow_check()
                        print('parameter okay')
                        code.write(',Parameterisation looks okay in ,PASS, \n')"""
                    
            
                    
                    #result=k.match(k)
                    #a=['a']
                    #result = re.match(r"(\bDB_DV.*$)", each['value'])
                    #a=a.append(result)
                    #code.write(a)
                    #if result:
                        #code.write(',update is happening on base table for,')
                        #code.write('FAIL')
                        #code.write(k)
                        #code.write('\n')
                    #else:
                        #code.write(',_dv is not found and parameterization looks fine,')
                        #code.write('FAIL')
                        #print(result)
                        #code.write('\n')
                
                #print(result)
                
                    #else:
                     #   code.write("nothing is working")
                      #  break
                    
                #for each in each['value']:
                #    if result[each] in each['value']:
                 #       #print ('found',result)
                 #       code.write(each['value'])
                    
                



       

        code.close();

extractQueries()
endTime=time.time()
execTime=endTime-startTime
#print("\tExecution Time : %f secs"%execTime);

