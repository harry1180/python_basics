import time
startTime=time.time();
import sanity_checks_xcel_op
import sanity_checks_final_xcel


endTime=time.time()
TotalexecTime=endTime-startTime
print("\tTotal Execution Time: %f secs"%TotalexecTime);
