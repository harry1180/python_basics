userInput=input("Enter a string : ")
def printToConsole(string):#user defined funtion
    """
    Takes a string as an Input and prints to console
    """
    print(string)
def revString(string):
    """
    Takes a string as an Input and returns the reversed string
    """
    return(string[::-1])
printToConsole(revString(userInput))
    
