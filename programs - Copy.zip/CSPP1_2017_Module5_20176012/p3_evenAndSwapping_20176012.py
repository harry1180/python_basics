def isEven(number):
    """
    Given a number, checks if it is even or odd
    """
    try:
        return not int(number)%2
    except:
        #print("Invalid Input")
        return -999
def swapValues(a,b):
    """
    Given two numbers, prints the numbers after swapping
    """
    temp=a
    a=b
    b=temp
    #print("At end of swapping function : X =",a,"Y =",b)
    return(a,b)
userInput=input("Enter a number to check its even parity: ")
if isEven(userInput)==-999:
    print("Invalid Input")
elif isEven(userInput):
    print(userInput,"is even number")
else:
    print(userInput,"is odd number")
print("    ")
x=input("Enter Num1: ")
y=input("Enter Num2: ")
print("Before calling swapping function : Num1 =",x,"Num2 =",y)
(x,y)=swapValues(x,y)
print("After coming out of swapping function :  Num1 =",x,"Num2 =",y)



