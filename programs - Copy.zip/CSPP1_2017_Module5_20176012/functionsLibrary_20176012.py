def revString(string):
    """
    Takes a string as an Input and returns the reversed string
    """
    return(string[::-1])
def swapValues(a,b):
    """
    Given two numbers, prints the numbers after swapping
    """
    temp=a
    a=b
    b=temp
    return(a,b)

