import functionsLibrary_20176012 as fL
print(fL.revString(input("Enter a string : ")))
(num1,num2)=(int(input("Num1 :")),int(input("Num2 :")))
print("Before swapping function :  Num1 =",num1,"Num2 =",num2)
(num1,num2)=fL.swapValues(num1,num2)
print("After coming out of swapping function :  Num1 =",num1,"Num2 =",num2)
