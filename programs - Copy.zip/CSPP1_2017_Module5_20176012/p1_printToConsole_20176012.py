userInput=input("Enter a string : ")
def printToConsole(string):#user defined funtion
    """
    Takes a string as an Input and prints to console
    """
    print(string)
printToConsole(userInput)
a=input("press 'Enter' to exit")
