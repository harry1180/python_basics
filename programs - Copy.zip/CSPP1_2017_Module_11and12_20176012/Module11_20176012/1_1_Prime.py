import timeit
def primeNumbersTill(n):
    n=int(n)
    for num in range(2,n+1):
        flag=0
        for i in range(2,num):
            if num%i==0:
                flag=1
                break
        if flag==0:
            print(num)
userInput=input("Enter a number :")
start=timeit.default_timer()
primeNumbersTill(userInput)
stop=timeit.default_timer()
print(stop-start)
