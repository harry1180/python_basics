def program3(L):
    totalSum=0
    highestFound=None
    for x in L:
        totalSum+=x
    for x in L:
        if highestFound ==None:
            highestFound=x
        elif x>highestFound:
            highestFound=x
    return(totalSum,highestFound)
print(program3(eval(input("Enter a list"))))
