def fib(n):
    if n==0:
        return 0
    elif n==1:
        print (1)
        return 1
    else:
        f1=0
        f2=1
        print(f1,f2,end=" ")
        for i in range(n-2):
            temp=f1
            f1=f2
            f2=temp+f2
            print (f2,end=" ") 
        return f2
fib(int(input()))
    
