"""def Primenumber(start, number):
  flag = 0
  for x in range(start,number/2):
      if(number % x == 0):
          flag=1
          break
  if(flag == 0):
      print ("Prime number")
  else:
      print ("not prime number")
#END of function

               
if __name__=="__main__":
    start = int(input("Enter start"))
    number = int(input("Enter Number"))
#Calling function
Primenumber(start,number)"""
def Primenumber(start, number):
  flag = 0
  start=2 #Added this line
  if (number==0 or number==1):#added if block
    print("not a prime")
  elif number>0:#added elif block
    for x in range(start,int(number**0.5)+1):#removed/2 and added **0.5
        if(number % x == 0):
            flag=1
            break
    if(flag == 0):
      print ("Prime number")
    else:
      print ("not prime number")
  else:#added else block
    print("Enter a positive number")
  
#END of function

               
if __name__=="__main__":
    start = int(input("Enter start"))
    number = int(input("Enter Number"))
Primenumber(start,number)
"""
start number output
0        2  Prime number
1        0  not a prime
4        4  not prime number

"""
