weekDays=("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
for i in weekDays:
    print(i)



