print("Enter a tuple in this format : (1,2,3)")
t=eval(input("Enter a tuple :"))
ui=input("Enter a value : ")
if t.count(eval(ui))>0:
    print(True)
else:
    print(False)
