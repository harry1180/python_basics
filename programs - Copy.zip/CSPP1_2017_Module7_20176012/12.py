"""cmp function can be used to compare two lists. However, it has been deprecated in python 3.0 and above"""
print("Type in list in this format: [1,2,3,4]")
l1=eval(input("Enter list1: "))
l2=eval(input("Enter list2: "))
if l1==l2:
    print(True)
else:
    print(False)
