t=(1,99,101,52,96,73)
print("Minimum: ",min(t))
print("Maximum: ",max(t))
print("Length: ",min(t))
print("List from tuple",list(t))

