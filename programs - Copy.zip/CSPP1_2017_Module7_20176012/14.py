print("Enter a list in this form : [1,2,3]")
a=eval(input("Enter ListA:"))
b=eval(input("Enter ListB:"))
c=[]
temp=len(a)//2
if len(a)%2==0:
    c.append(a[temp-1])
    c.append(a[temp])
else:
    c.append(a[temp])
temp=len(b)//2
if len(b)%2==0:
    c.append(b[temp-1])
    c.append(b[temp])
else:
    c.append(b[temp])
print(c)
