length=int(input("Enter length of list :"))
intList=[]
for i in range(length):
    intList.append(eval(input("Enter a value : ")))
for i in intList:
    if i%2==0:
        print(i)
