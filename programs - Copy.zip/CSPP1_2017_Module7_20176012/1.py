tup1=('msit','info',97,22);
tup2=(1,2,3,4,5,6,7)
print(tup1[1])
print(tup2[1:5])
###############
tinytuple=(123,'john')
print(tinytuple*2)
###############
list=['14','70',1997,2000]
list[3]=100
print(list[3])
###############
result=[]
for x in range(5):
    if x%2==0:
        for y in range(5):
            if y%2==1:
                result.append((x,y))
print(result)
###############
x=[1,2,3]
x.append([4,5])
x.extend([4,5])
print(x)
##############
def extendList(val,list=[]):
    print("ID: ",id(list))
    list.append(val)
    return list
list1=extendList(10)
list2=extendList(123,[])
list3=extendList('a')
print("list1 = %s"%list1)
print("list2 = %s"%list2)
print("list3 = %s"%list3)
###############
result=[]
for x in [10,20,30]:
    for y in [2,3,4]:
        result.append(x**y)
print(result)

