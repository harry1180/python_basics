tuple1=eval(input("Enter a tuple1: " ))
tuple2=eval(input("Enter a tuple2: "))
print(tuple1+tuple2)
