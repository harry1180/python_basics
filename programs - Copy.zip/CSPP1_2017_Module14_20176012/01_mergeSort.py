"""Generate "k" random numbers and sort them using merge sort. Where k is given below:
a. k = 10
b. k = 15
c. k = 25
"""
import random
def mergeTwoLists(left,right):
    newList=[]
    i=j=0
    while i<len(left) and j<len(right):
        if left[i]<right[j]:
            newList.append(left[i])
            i+=1
        else:
            newList.append(right[j])
            j+=1
    if i<len(left):###You can use append if you go with while instead of if clause
        newList.extend(left[i:])
    if j<len(right):###You can use append if you go with while instead of if clause
        newList.extend(right[j:])
    return newList
def mergeSort(l):
    if len(l)<2:
        return l[:]
    else:
        mid=len(l)//2
        left=mergeSort(l[:mid])
        right=mergeSort(l[mid:])
        return mergeTwoLists(left,right)
for i in (5,10,15):
    numList=random.sample(range(0,250),i)
    print("List with {} random numbers : {}".format(i,numList))
    print("List after merge sorting:",mergeSort(numList))
    print("#############################")
