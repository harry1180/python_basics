class ageError(Exception):
    pass
def isEligible(age):
    try:
        age=float(age)
        if age>=18 and age<=35:
            return 1
        else:
            raise ageError
    except ageError:
        return "You are not eligible"
    except:
        return -999
a=input("Enter you age : ")
output=isEligible(a)
if output==1:
    print("Eligible")
elif output==-999:
    print("Enter Valid Values")
else:
    print(output)
