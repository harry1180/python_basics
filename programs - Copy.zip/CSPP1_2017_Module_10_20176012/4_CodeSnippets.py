"""a=1
b=10
my_list=[]
for x in range(a,b):
    print("(%f, %f, %f)"%my_list[x])
####
import math
dividend=float(input("Please enter the dividend : "))
divisor=float(input("Please enter the divisor : "))
quotient=dividend/divisor
quotient_rounded=math.round(quotient)
print(quotient_rounded)
"""
class MyError(Exception):
    def __init__(self,value):
        self.value=value
    def __str__(self):
        return repr(self.value)
try:
    raise MyError(2*2)
except MyError as e:
    print ('My Exception Occured, value: ',e)
