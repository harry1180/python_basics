def multTable(num,limit=10):
    for i in range(10):
        print(num,"X",i+1,"=",num*limit)
a=(input("Enter a number"))
try:
    assert int(a)>=0,"negative"
    multTable(int(a))
except AssertionError:
    print("Enter positive values")
except:
    print("Enter Valid Value")

