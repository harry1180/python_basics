import math
def squareRoot(num):
    try:
        num=float(num)
        return math.sqrt(num)
    except ValueError:
        return "Give proper Input"
    except:
        return "Invalid Input"
n=input("Enter a number : ")
print(squareRoot(n))
