ui=input("Enter a string : ")
d={}
for i in ui:
    if i in d.keys():
        d[i]=d[i]+1
    else:
        d[i]=1
print("Freq Dictionary: ",d)
