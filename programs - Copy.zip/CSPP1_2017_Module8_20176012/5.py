import math
l=eval(input("Enter a list: "))
print("Original List : ",l)
def squareroot(i):
    return math.sqrt(i)
def srEachValue(l,f):
    for i in range(len(l)):
        l[i]=f(l[i])
srEachValue(l,squareroot)
print("Modified List",l)
        
        


