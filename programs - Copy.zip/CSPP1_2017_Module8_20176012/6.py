d={1:'One',2:'Two',3:'Three',4:'Four',5:'Five',6:'Six',7:'Seven',8:'Eight',9:'Nine'}
ip=int(input("Enter a integer: "))
if ip in d.keys():
    print(d[ip])
else:
    print("Not present")
