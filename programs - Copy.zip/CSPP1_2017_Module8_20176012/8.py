ui=input("Enter a string : ")
d={}
for i in ui:
    if i in d.keys():
        d[i]=d[i]+1
    else:
        d[i]=1
print("Freq Dictionary: ",d)




items=d.items()
print(items)
newD={}
for i in items:
    if i[1] not in newD.keys():
        newD[i[1]]=[]
        newD[i[1]].append(i[0])
    else:
        newD[i[1]].append(i[0])
print("Letters with same freq: ",newD)
