def myfunc1():
    print("hello")
def myfunc2(func):
    print("world")
myfunc2(myfunc1())
################
def A_function(f,b,c):
    return f(b,c)
def f(a,b):
    return a*b
print(A_function(f,10,20))
################
x={"a":1,"b":2}
y={"b":10,"c":11}
z=x.copy()
z.update(y)
print(z)

##############
keys=['a','b','c']
values=[1,2,3]
print (list(zip(keys,values)))
