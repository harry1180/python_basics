def nThFibonacci(n):
    """
    takes input in the form of string and gives nth fibonacci number
    """
    try:
        n=int(n)
        if n==1:
            return 0
        elif n==2:
            return 1
        else:
            return nThFibonacci(n-1)+nThFibonacci(n-2)
    except:
        print("Enter integers > 0")
        return -999
userInput=input("Enter a number : ")
try:
    userInput=int(userInput)
    if userInput>0:
        print("Fibonacci Series : ")
        for i in range(1,userInput+1):
            print(nThFibonacci(str(i)),end=" ")
    else:
        print("Enter Valid Values")
except:
    print("Enter Valid Values")
    
