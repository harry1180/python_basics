def revOrder(string):
    """
    prints reverse of a given number in the form of a string 
    """
    try:
        integer=int(string)
        if integer==0:
            return 1
        else:
            print(integer)
            return revOrder(str(integer-1))
    except:
        print("Invalid Input")

userInput=input("Enter a number : ")
revOrder(userInput)
