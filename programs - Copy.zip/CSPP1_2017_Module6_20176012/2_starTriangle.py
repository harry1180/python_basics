def starTriangle(string):
    """
    prints a triangle for a given number in the form of a string 
    """
    try:
        string=int(string)
        for i in range(string):
            print ("* "*(i+1))
    except:
        print("Invalid Input")

userInput=(input("Enter a number : "))
starTriangle(userInput)
