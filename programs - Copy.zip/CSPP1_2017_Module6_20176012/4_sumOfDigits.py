def sumOfDigitsWhile(string):
    """
    prints sum of digits in a given number in the form of a string using while loop
    """
    try:
        integer=abs(int(string))
        totalSum=0
        while (integer/10!=0):
            totalSum+=(integer%10)
            integer//=10
        return totalSum
            
    except:
        print("Pls enter integers")
        return -999
        
def sumOfDigitsFor(string):
    """
    prints sum of digits in a given number in the form of a string using for loop
    """
    try:
        integer=abs(int(string))
        totalSum=0
        for i in range(0,len(str(integer)),1):
            totalSum+=(integer%10)
            integer//=10              
        return totalSum
            
    except:
        print("Pls enter integers")
        return -999

userInput=input("Enter a number : ")
if sumOfDigitsWhile(userInput)!=-999:
    print("Sum of Digits using while loop :",sumOfDigitsWhile(userInput))
if sumOfDigitsFor(userInput)!=-999:
    print("Sum of Digits using for loop :",sumOfDigitsFor(userInput))

