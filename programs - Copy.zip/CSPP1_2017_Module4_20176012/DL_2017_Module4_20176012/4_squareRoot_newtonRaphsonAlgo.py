import sys
userInput=input("Enter a number : ")
try:
    userInput=int(userInput)
    if userInput<0:
        negFlag=1
    else:
        negFlag=0
    absuserInput=abs(userInput)
except:
    print("Enter only integers")
    sys.exit()
delta=0.01
value=absuserInput/2.0
guessCount=0
while abs(value**2-absuserInput)>=delta:
    value=value-(((value**2)-absuserInput)/(2*absuserInput))
    guessCount+=1
if negFlag==0:
    print("Approximate Square root of",absuserInput,"is",value)
    print("Count of Guesses : ",guessCount)
else:
    print("Approximate Complex Square root of",absuserInput,"is",str(value)+"i")
    print("Count of Guesses : ",guessCount)
input("press any key to exit")

