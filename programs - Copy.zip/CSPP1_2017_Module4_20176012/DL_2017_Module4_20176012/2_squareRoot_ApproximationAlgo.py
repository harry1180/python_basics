import sys
userInput=input("Enter a number : ")
try:
    userInput=int(userInput)
    if userInput<0:
        negFlag=1
    else:
        negFlag=0
    absuserInput=abs(userInput)
except:
    print("Enter only integers")
    sys.exit()
delta=0.01
init=0.0
incr=0.001
guessCount=0
while abs(init**2-absuserInput)>=delta and init<absuserInput:
    #print("init :",init)
    init+=incr
    guessCount+=1
if negFlag==0:
    print("Approximate Square root of %d is %f "%(absuserInput,init))
    print("Count of Guesses : ",guessCount)
else:
    print("Approximate complex Square root of",absuserInput,"is",str(init)+"i")
    print("Count of Guesses : ",guessCount)
input("press any key to exit")
    
