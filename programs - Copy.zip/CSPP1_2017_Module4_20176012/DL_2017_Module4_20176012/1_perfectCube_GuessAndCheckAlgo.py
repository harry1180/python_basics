import sys
userInput=input("Enter a number : ")
try:
    userInput=int(userInput)
    absuserInput=abs(userInput)
except:
    print("Enter only integers")
    sys.exit()
init=0
i=1
guessCount=0
for i in range(init,absuserInput+1,1):
    guessCount+=1
    if(i**3>=absuserInput):
        break
if (i**3==absuserInput):
    print("No of Guesses : ",guessCount)
    if userInput<0:
        print(userInput, "is a perfect cube of ",-i)
    else:
        print(userInput, "is a perfect cube of ",i)
else:
    print("No of Guesses : ",guessCount)
    print(userInput, "is not a perfect cube")
input("press any key to exit")
