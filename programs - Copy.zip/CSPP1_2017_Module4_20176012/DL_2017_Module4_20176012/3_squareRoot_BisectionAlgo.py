import sys
userInput=input("Enter a number : ")
try:
    userInput=int(userInput)
    if userInput<0:
        negFlag=1
    else:
        negFlag=0
    absuserInput=abs(userInput)
except:
    print("Enter only integers")
    sys.exit()
"""userInput=float(userInput)
absuserInput=abs(userInput)"""
delta=0.00001
minValue=0
maxValue=userInput
value=(minValue+maxValue)/2.0
guessCount=0
while abs(value**2-absuserInput)>=delta:
    print("Min Value :",minValue,"Max Value : ",maxValue)
    #if guessCount>25:
     #   break
    if value**2<absuserInput:
        minValue=value
    else:
        maxValue=value
    value=(minValue+maxValue)/2.0
    guessCount+=1
#print("Final Delta :",abs(value**2-absuserInput))
if negFlag==0:
    print("Approximate Square root of",absuserInput,"is",value)
    print("Count of Guesses : ",guessCount)
else:
    print("Approximate Square root of",absuserInput,"is",str(value)+"i")
    print("Count of Guesses : ",guessCount)
input("press any key to exit")
