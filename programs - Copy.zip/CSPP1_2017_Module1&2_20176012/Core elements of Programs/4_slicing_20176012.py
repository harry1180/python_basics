userInput=input("Enter a sring :")
lenStr=len(userInput)
print(userInput[1:lenStr-1])
