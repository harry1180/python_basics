userDate=input("Enter a dd-mm-yyyy format date : ")
if len(userDate)!=10 and userDate[2]!='-' and userDate[2]!='-':
    print("Invalid Input")
else:
    year=userDate[6:]
    year=int(year)
    if (year%100)==0:
        if year%400==0:
            print("Leap Year")
        else:
            print("Not a Leap Year")
    else:
        if year%4==0:
            print("Leap Year")
        else:
            print("Not a Leap Year")

