a=16
b=59
c=48
d=37
"""temp1=b*c
temp2=a*b
print ("Step1 : ","b*c","Output : ",b*c)
print ("Step1 : ","a*b","Output : ",a*b)
print ("Step2 : ","a+b*c+d","Output : ",a+temp1+d)
temp1=a+temp1+d
print ("Step2 : ","a*b-c","Output : ",temp2-c)
temp2=temp2-c
print ("Step3 : ","(a+b*c+d)/(a*b-c)","Output : ",temp1/temp2)"""

print ("Step1 : ","b*c","Output : ",b*c)
print ("Step2 : ","a+b*c","Output : ",a+b*c)
print ("Step3 : ","a+b*c+d","Output : ",a+b*c+d)
print ("Step4 : ","a*b","Output : ",a*b)
print ("Step5 : ","a*b-c","Output : ",a*b-c)
print ("Step6 : ","(a+b*c+d)/(a*b-c)","Output : ",(a+b*c+d)/(a*b-c))




