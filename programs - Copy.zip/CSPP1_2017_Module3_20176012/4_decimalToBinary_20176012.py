userInput=int(input("Enter Decimal number : "))
i=0
totalSum=0
binary=""
rem=0
if userInput>=0:
    while((userInput)!=0):
        rem=userInput%2
        binary=str(rem)+binary
        userInput=userInput//2
        i+=1
else:
    print("Invalid")
print(binary)
input("press any key to exit")

