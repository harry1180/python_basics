userInput=int(input("Enter a number : "))
limit=10
for i in range(1,limit+1):
    #if i!=5:
    print(userInput,"X",i," = ",userInput*i)

input("press any key to exit")
