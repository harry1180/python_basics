userInput=int(input("Enter a number : "))
i=0
totalSum=0
count=0
if (userInput>0):
    while(count<userInput):
        if i%2==0:
            print(i)
            totalSum+=i
            count+=1
        i=i+2
else:
    print("Invalid")
    
print("Total Sum :",totalSum)
input("press any key to exit")

