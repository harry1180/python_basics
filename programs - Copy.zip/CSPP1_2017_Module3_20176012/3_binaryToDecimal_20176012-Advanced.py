userInput=input("Enter binary number : ")
count=len(userInput.split("."))
if count==1:
    ppart=int(userInput.split(".")[0])
elif count==2:
    ppart=int(userInput.split(".")[0])
    dpart=userInput.split(".")[1]
    userInput=ppart
else:
    print("Invalid")
    exit()
i=0
totalSum=0
rem=0
flag=1
if int(userInput)>=0:
    userInput=ppart
    while(userInput!=0 and flag==1):
        rem=userInput%10
        if rem==0 or rem==1:
            totalSum=totalSum+rem*(2**i)
        else:
            flag=0
            break
        userInput=userInput//10
        i+=1
    if count==2:
        temp=-1
        i=0
        while(flag==1 and i<len(dpart)):
            rem=int(dpart[i])
            if rem==0 or rem==1:
                totalSum=totalSum+rem*(2**temp)
                temp=temp-1
            else:
                flag=0
                break
            i+=1
    if flag==1:
        print("Decimal Number :",totalSum)
    else:
        print("Invalid")
else:
    print("Invalid")
input("press any key to exit")

