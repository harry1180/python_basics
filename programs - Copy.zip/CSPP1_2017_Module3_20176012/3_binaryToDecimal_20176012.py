userInput=int(input("Enter binary number : "))
i=0
totalSum=0
rem=0
flag=1
if userInput>=0:
    while((userInput)!=0 and flag==1):
        rem=userInput%10
        if rem==0 or rem==1:
            totalSum=totalSum+rem*(2**i)
        else:
            flag=0
            break
        userInput=userInput//10
        i+=1
    if flag==1:
        print("Decimal Number :",totalSum)
    else:
        print("Invalid")
else:
    print("Invalid")
input("press any key to exit")

