import random
class Question(object):
    global qCount
    qCount=1
    i=10
    def __init__(self,qID=qCount,qText="Question Missing",qOptions=[0,1,2,3],qAnswer=random.choice([1,2,3,4]),qMarks=5):
        self.qID=qID
        self.qText=qText
        self.qOptions=qOptions
        self.qAnswer=qAnswer
        self.qMarks=qMarks
    qCount+=1
    def get_qID(self):
        return self.qID
    def get_qText(self):
        return self.qText
    def get_qOptions(self):
        return self.qOptions
    def get_qAnswer(self):
        return self.qAnswer
    def get_qMarks(self):
        return self.qMarks
    def set_qID(self,id):
        self.qID=id
    def set_qText(self,text):
        self.qText=text
    def set_qOptions(self,optionsList):
        if type(optionsList)==list:
            self.qOptions=optionsList
        else:
            print("Give valid options")
    def set_qAnswer(self,answer):
        temp=list(range(len(self.get_qOptions())))
        #print("temp: ",temp)
        if answer in temp:
            self.qAnswer=answer
        else:
            print("Give correct option")
    def set_qMarks(self,marks):
        self.qMarks=marks
if __name__=="__main__":
    q1=Question()
    # print(q1.get_qID())
    # print(q1.get_qText())
    # print(q1.get_qOptions())
    # print(q1.get_qAnswer())
    # print(q1.get_qMarks())
    
    id=input("Enter Question ID: ")
    q1.set_qID(id)
    text=input("Enter Question")
    q1.set_qText(text)
    options=eval(input("Enter a list of options in this format ['Ramu','Raju','Chandra','Ramesh']:"))
    q1.set_qOptions(options)
    answer=input("Enter option (correct answer index in above list):")
    q1.set_qAnswer(answer)
    marks=input("Enter marks scored")
    q1.set_qMarks(marks)
    print(getattr(q1,"qID"))
##    q1.set_qID(1)
##    q1.set_qText("Who is the founder of facebook?")
##    q1.set_qOptions(["Bill Gates","Steve Jobs","Mark Zuckerberg","Tim Cook"])
##    q1.set_qAnswer(2)
##    q1.set_qMarks(5)
    print("Question ID :",q1.get_qID())
    print("Question :",q1.get_qText())
    print("Options :",q1.get_qOptions())
    print("Correct Answer Index:",q1.get_qAnswer())
    print("Marks :",q1.get_qMarks())

