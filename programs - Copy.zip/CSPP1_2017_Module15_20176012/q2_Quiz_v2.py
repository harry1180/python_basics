import q1_QuestionClass as q
import random
totalMarks=0
class quiz(object):
    global qList
    limit=10
    qList=[]
    def addQuestion(self,**qParams):
        params=qParams
        temp=q.Question()
        temp.set_qID(params.get("qID"))
        temp.set_qText(params.get("qText"))
        temp.set_qOptions(params.get("qOptions"))
        temp.set_qAnswer(params.get("qAnswer"))
        temp.set_qMarks(params.get("qMarks"))
        qList.append(temp)
    def startQuiz(self):
        qOrder=random.sample(range(0,len(qList)),quiz.limit)
        global totalMarks
        count=1
        for i in qOrder:
            print(str(count)+")"+qList[i].get_qText())
            temp=0
            for j in qList[i].get_qOptions():
                print(str(temp+1)+")"+str(j))
                temp+=1
            print(chr(10))
            flag=1
            while(flag==1):
                try:
                    userInput=int(input("Enter answer : "))
                    flag=0
                except:
                    print("Enter valid option")
            if (qList[i].get_qAnswer()+1)!=userInput:
                break
            else:
                totalMarks+=qList[i].get_qMarks()
            count+=1
            print("----------------------------------------------------------------------")
if __name__=="__main__":
    pDict={}
    pDict[0]={"qID":1,"qText":"Who is current President of America?","qOptions":["Donald Trump","Barack Obama","George Bush","Abraham Lincoln"],"qAnswer":0,"qMarks":1}
    pDict[1]={"qID":2,"qText":"What is capital of India?","qOptions":["Tokyo","Rajasthan","Hyderabad","Delhi"],"qAnswer":3,"qMarks":1}
    pDict[2]={"qID":3,"qText":"India became independent in year ________","qOptions":["1907","1947","2012","2025"],"qAnswer":1,"qMarks":1}
    pDict[3]={"qID":4,"qText":"Full form of ALU?","qOptions":["Arithmetic and Logical Unit","All logic Unit","Arithmetic Legal Unit","Another Linked Unit"],"qAnswer":0,"qMarks":1}
    pDict[4]={"qID":5,"qText":"Function for length of a string in python","qOptions":["length()","len()","str_length()","length_str()"],"qAnswer":1,"qMarks":1}
    pDict[5]={"qID":6,"qText":"Total no. of states in India","qOptions":["23","25","26","29"],"qAnswer":3,"qMarks":1}
    pDict[6]={"qID":7,"qText":"Who invented Pencillin?","qOptions":["John Mark","Edison","Alexander Fleming","Arjun Kapoor"],"qAnswer":2,"qMarks":1}
    pDict[7]={"qID":8,"qText":"Total no. of circles in Olympics Logo are ________","qOptions":["6","5","20","7"],"qAnswer":1,"qMarks":1}
    pDict[8]={"qID":9,"qText":"First IIT was laid foundation by ________","qOptions":["Indira Gandhi","Mahatma Gandhi","Jawaharlal Nehru","Sarojini Naidu"],"qAnswer":2,"qMarks":1}
    pDict[9]={"qID":10,"qText":"Current CEO of Google Inc.?","qOptions":["Bill Gates","Larry Page","Sergey Brin","Sundar Pichai"],"qAnswer":3,"qMarks":1}
    pDict[10]={"qID":11,"qText":"Who built the world's first binary digit computer: Z1...?","qOptions":["Konrad Zuse","Ken Thompson","Alan Turing","George Boole"],"qAnswer":0,"qMarks":1}
    pDict[11]={"qID":12,"qText":"'.INI' extension refers usually to what kind of file?","qOptions":["Image file","System file","Hypertext related file","Image Color Matching Profile file"],"qAnswer":1,"qMarks":1}
    pDict[12]={"qID":13,"qText":"The first graphical browser for the WWW was named ________","qOptions":["Netscape","Mosaic","Veronica","Firefox"],"qAnswer":1,"qMarks":1}
    pDict[13]={"qID":14,"qText":"How many generations of computers we have?","qOptions":["6","7","5","4"],"qAnswer":2,"qMarks":1}
    pDict[14]={"qID":15,"qText":"The term 'Pentium' is related to ________","qOptions":["DVD","HardDisk","MicroProcessor","Mouse"],"qAnswer":2,"qMarks":1}
    pDict[15]={"qID":16,"qText":"Which of the following is used for close a tab on a browser?","qOptions":["Ctrl + Y","Ctrl + A","Ctrl + W","Ctrl + T"],"qAnswer":2,"qMarks":1}
    print("\t\tWelcome to Kaun Banega Crorepati\n")
    userQuiz=quiz()
    for i in range(len(pDict)):
        userQuiz.addQuestion(**pDict[i])
    userQuiz.startQuiz()
    print(chr(10))
    print("Total Score : ",totalMarks)
    print("\nThank You! Wanna Try Once More?")


