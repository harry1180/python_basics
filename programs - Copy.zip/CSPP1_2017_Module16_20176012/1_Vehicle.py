class Vehicle(object):
    def __init__(self,speed=None,color=None,fuel=None):
        self.speed=speed
        self.color=color
        self.fuel=fuel
    def get_speed(self):
        return self.speed
    def get_color(self):
        return self.color
    def get_fuel(self):
        return self.fuel
    def set_speed(self,speed):
        self.speed=speed
    def set_color(self,color):
        self.color=color
    def set_fuel(self,fuel):
        self.fuel=fuel
    def start(self):
        return "Vehicle Started"
    def stop(self):
        return "Vehicle Stopped"
    def __str__(self):
        return "I am a vehicle"
class Car(Vehicle):
    def __init__(self,model=None):
        Vehicle.__init__(self)
        self.model=model
    def moveFront(self,meters):
        return "{} moved {} meters front".format(self.__class__.__name__,meters)
    def moveBack(self,meters):
        return "{} moved {} meters back".format(self.__class__.__name__,meters)
    def moveLeft(self,meters):
        return "{} moved {} meters left".format(self.__class__.__name__,meters)
    def moveRight(self,meters):
        return "{} moved {} meters right".format(self.__class__.__name__,meters)
    def __str__(self):
        return "I am a {} of model {}".format(self.__class__.__name__,self.model)
class SportsCar(Car):
    def __init__(self,horsepower=0):
        Car.__init__(self)
        #self.model=model
        self.horsepower=horsepower
    def accelerate(self,rate=5):
        return "I,{} accelerated at {} m/s^2".format(self.model,str(rate))
    def __str__(self):
        #print("hello ",self.__class__.__name__)
        #print("wewe",self.model)
        return "I am a {} of model {}".format(self.__class__.__name__,(self.model))
        #return str(self.model)

c=Car("Mercedes Benz")
c.set_color("Red")
print(c)
s=SportsCar("Mercedes")
print(s)



