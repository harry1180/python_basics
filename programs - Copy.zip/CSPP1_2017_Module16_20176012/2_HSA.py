class Person(object):
    def __init__(self,name=None,age=0):
        self.name=name
        self.age=age
    def get_name(self):
        return self.name
    def set_name(self,name):
        self.name=name
    def get_age(self):
        return self.age
    def set_age(self,age):
        self.age=age
    def display(self):
        print("Name :"+self.name+"\n"+"Age :"+str(self.age))
p=Person("Raja",26)
p.display()
class Student(Person):
    def __init__(self,Student_ID=1,Average_Marks=10):
        Person.__init__(self)
        self.Student_ID=Student_ID
        self.Average_Marks=Average_Marks
    def display(self):
        print("Student_ID :"+str(self.Student_ID)+"\n"+"Average_Marks :"+str(self.Average_Marks))
class Teacher(Student):
    def __init__(self,Salary=0,Subject=None):
        Student.__init__(self)
        self.Salary=Salary
        self.Subject=Subject
    def display(self):
        print("Salary :"+str(self.Salary)+"\n"+"Subject :"+str(self.Subject))
class gen(object):#1st way to implement generator using class
    def __init__(self,n,start=0):
        self.limit=n
        self.start=start
    def __iter__(self):
        return self
    def __next__(self):
        return self.next()
    def next(self):
        if self.start<self.limit:
            temp,self.start=self.start,self.start+1
            return temp
        else:
            raise StopIteration()
def generateN(limit): #way of implementing generator using function
    start = 0
    while start < limit:
        yield start
        start += 1
i=1
for i in range(10):
    print(next(gen(i)))

    
sList=[]
s1=Student(1,50)
s2=Student(2,50)
sList.append(s1)
sList.append(s2)
for i in sList:
    i.display()
    
print("-----------------")
tList=[]
t1=Teacher(5000,"Maths")
t2=Teacher(10000,"Science")
t1.set_name("Ramu")
t1.set_age(40)
t2.set_name("Rahul")
t1.set_age(60)
tList.append(t1)
tList.append(t2)
g=gen(len(tList)) #using generator
for i in g:
    print(tList[i].get_name())
    print(tList[i].get_age())
    tList[i].display()
    print("\n")



