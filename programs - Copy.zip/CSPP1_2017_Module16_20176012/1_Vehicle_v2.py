class Vehicle(object):
    def __init__(self,speed=5,color=None,fuel=None):
        self.speed=speed
        self.color=color
        self.fuel=fuel
    def get_speed(self):
        return self.speed
    def get_color(self):
        return self.color
    def get_fuel(self):
        return self.fuel
    def set_speed(self,speed):
        self.speed=speed
    def set_color(self,color):
        self.color=color
    def set_fuel(self,fuel):
        self.fuel=fuel
    def start(self):
        return "Vehicle Started"
    def stop(self):
        return "Vehicle Stopped"
    def __str__(self):
        #return "I am a vehicle \nSpeed :  \nColor:  \nFuel: ".format(self.speed)
        return ("I am a vehicle \nSpeed :%s  \nColor:%s  \nFuel:%s "%(self.speed,self.color,self.fuel))
class Car(Vehicle):
    def __init__(self,model=None):
        Vehicle.__init__(self)
        self.model=model
    def get_model(self):
        return self.model
    def set_model(self,model):
        self.model=model
    def moveFront(self,meters):
        return "{} moved {} meters front".format(self.__class__.__name__,meters)
    def moveBack(self,meters):
        return "{} moved {} meters back".format(self.__class__.__name__,meters)
    def moveLeft(self,meters):
        return "{} moved {} meters left".format(self.__class__.__name__,meters)
    def moveRight(self,meters):
        return "{} moved {} meters right".format(self.__class__.__name__,meters)
    # def __str__(self):
# ##        return "I am a {} of model {}".format(self.__class__.__name__,self.model)
        # return "I am a %s of model %s"%(self.__class__.__name__,self.model)
class SportsCar(Car):
    def __init__(self,model="None2",horsepower=0):
        Car.__init__(self,model)
        self.horsepower=horsepower
    def get_horsepower(self):
        return self.horsepower
    def set_horsepower(self,horsepower):
        self.horsepower=horsepower
    def accelerate(self,rate=5):
        return "I,{} accelerated at {} m/s^2".format(self.model,str(rate))
    def __str__(self):
        #print("hello ",self.__class__.__name__)
        #print("wewe",self.model)
        # return "I am a %s of model %s"%(self.__class__.__name__,(self.model))
        # return "I am a "+str(self.__class__.__name__)+"of model"+str(self.model)
        return "I am a sportscar with "+str(self.horsepower)+" horsepower"
c=Car()
c.set_speed(5)
c.set_color("Red")
c.set_fuel("50 L")
print(c)
print("------------------------")
s=SportsCar("Benz")
s.set_speed(60)
s.set_color("Blue")
s.set_fuel("80 L")
s.set_horsepower(20)
print(s.get_speed())
print(s.get_color())
print(s.get_fuel())
print(s.get_model())
print(s.get_horsepower())



