def binarySearch(searchList,element):
    global count
    def rangeSetter(searchList,element,low,high):
        #nonlocal count
        global count,steps
        steps+=1
        count+=1
        if high==low:
            count+=1
            return searchList[low]==element
        mid=(low+high)//2
        count+=1
        if searchList[mid]==e:
            return True
        elif searchList[mid]>e:
            count+=2
            """considering the number we entered is not there\
            and is less than minimum of the entire list, we write below if block"""
            if low==mid:
                return False
            else:
                count+=1
                return rangeSetter(searchList,element,low,mid-1)
        else:
            count+=2
            return rangeSetter(searchList,element,mid+1,high)
    length=len(searchList)
    count+=1
    if searchList==[]:
        return 0
    else:
        return rangeSetter(searchList,element,0,len(searchList)-1)
count=0
steps=0
sL=[23,1,45,90,12,34,14,59,21,107,10,5,18,19,20]
sL.sort()
print(sL)
#e=eval(input("Enter a value :"))
e=10
print(binarySearch(sL,e))
print("No.of Comparisons : ",count)
print("No.of Steps : ",steps)