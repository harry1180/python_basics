count=0
def linearSearch(searchList,element):
    global count
    for i in searchList:
        count+=1
        if i==element:
            return True
    return False
sL=[23,1,45,90,12,34,14,59,21,107,10,5,18,19,20]
#e=eval(input("Enter a value :"))
e=10
print(linearSearch(sL,e))
print("No.of Comparisons : ",count)